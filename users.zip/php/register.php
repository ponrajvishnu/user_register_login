<?php
include_once('db_connection.php');
$con = db_connect();

include('../register.html');

?>